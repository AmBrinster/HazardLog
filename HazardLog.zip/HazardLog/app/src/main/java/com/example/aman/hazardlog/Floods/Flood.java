package com.example.aman.hazardlog.Floods;

import android.os.Parcel;
import android.os.Parcelable;

public class Flood implements Parcelable {

    private String startDate;
    private String endDate;
    private String description;
    private String url;
    private String populationStatus;
    private String severityStatus;
    private String country;
    private String mapDescription;
    private String mapUrl;
    private double latitude;
    private double longitude;
    private String crisisLevel;
    private double exactPopulation;

    public Flood(String startDate, String endDate, String description, String url, String populationStatus, String severityStatus, String country, String mapDescription, String mapUrl, double latitude, double longitude, String crisisLevel, double exactPopulation) {
        this.startDate = startDate;
        this.endDate = endDate;
        this.description = description;
        this.url = url;
        this.populationStatus = populationStatus;
        this.severityStatus = severityStatus;
        this.country = country;
        this.mapDescription = mapDescription;
        this.mapUrl = mapUrl;
        this.latitude = latitude;
        this.longitude = longitude;
        this.crisisLevel = crisisLevel;
    }

    private Flood(Parcel in) {
        startDate = in.readString();
        endDate = in.readString();
        description = in.readString();
        url = in.readString();
        populationStatus = in.readString();
        severityStatus = in.readString();
        country = in.readString();
        mapDescription = in.readString();
        mapUrl = in.readString();
        latitude = in.readDouble();
        longitude = in.readDouble();
        crisisLevel = in.readString();
        exactPopulation = in.readDouble();
    }

    public static final Creator<Flood> CREATOR = new Creator<Flood>() {
        @Override
        public Flood createFromParcel(Parcel in) {
            return new Flood(in);
        }

        @Override
        public Flood[] newArray(int size) {
            return new Flood[size];
        }
    };

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPopulationStatus() {
        return populationStatus;
    }

    public void setPopulationStatus(String populationStatus) {
        this.populationStatus = populationStatus;
    }

    public String getSeverityStatus() {
        return severityStatus;
    }

    public void setSeverityStatus(String severityStatus) {
        this.severityStatus = severityStatus;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getMapDescription() {
        return mapDescription;
    }

    public void setMapDescription(String mapDescription) {
        this.mapDescription = mapDescription;
    }

    public String getMapUrl() {
        return mapUrl;
    }

    public void setMapUrl(String mapUrl) {
        this.mapUrl = mapUrl;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public String getCrisisLevel() {
        return crisisLevel;
    }

    public void setCrisisLevel(String crisisLevel) {
        this.crisisLevel = crisisLevel;
    }

    public double getExactPopulation() {
        return exactPopulation;
    }

    public void setExactPopulation(double exactPopulation) {
        this.exactPopulation = exactPopulation;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(startDate);
        parcel.writeString(endDate);
        parcel.writeString(description);
        parcel.writeString(url);
        parcel.writeString(populationStatus);
        parcel.writeString(severityStatus);
        parcel.writeString(country);
        parcel.writeString(mapDescription);
        parcel.writeString(mapUrl);
        parcel.writeDouble(latitude);
        parcel.writeDouble(longitude);
        parcel.writeString(crisisLevel);
        parcel.writeDouble(exactPopulation);
    }
}
