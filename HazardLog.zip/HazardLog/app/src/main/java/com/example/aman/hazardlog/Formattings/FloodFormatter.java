package com.example.aman.hazardlog.Formattings;

import android.content.Context;
import android.support.v4.content.ContextCompat;

import com.example.aman.hazardlog.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class FloodFormatter {

    Context context;

    public FloodFormatter(Context context) {
        this.context = context;
    }

    public int getMagnitudeColor(String magnitude){
        int magResourceId;
        switch (magnitude){
            case "Red":
                magResourceId = R.color.magnitude9;
                break;
            case "Orange":
                magResourceId = R.color.magnitude5;
                break;
            case "Green":
                magResourceId = R.color.magnitude2;
                break;
            default:
                    magResourceId = R.color.magnitude1;
                    break;
        }
        return ContextCompat.getColor(context, magResourceId);
    }

    public String formatMag(String mag){
        String formattedMag;
        switch (mag){
            case "Red":
                formattedMag = "Severe";
                break;
            case "Orange":
                formattedMag = "Moderate";
                break;
            case "Green":
                formattedMag = "Minor";
                break;
            default:
                formattedMag = "Minor";
                break;
        }
        return formattedMag;
    }

    public String formatDate(String date) throws ParseException {
        String formatDate = date.substring(0,10);
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        Date date1 = fmt.parse(formatDate);
        SimpleDateFormat fmtOut = new SimpleDateFormat("LLL dd, yyyy", Locale.US);
        return fmtOut.format(date1);
    }

}
