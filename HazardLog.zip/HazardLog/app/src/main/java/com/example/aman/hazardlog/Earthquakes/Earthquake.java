package com.example.aman.hazardlog.Earthquakes;

import android.os.Parcel;
import android.os.Parcelable;

public class Earthquake implements Parcelable {

    private double magnitude;
    private String location;
    private long time;
    private String url;
    private double mLat, mLon;
    private int mTsunami;
    private String mDetail;

    public Earthquake(double mag, String loc, long time, String url, double lat, double lon, int tsunami, String detail) {
        this.magnitude = mag;
        this.location = loc;
        this.time = time;
        this.url = url;
        this.mLat = lat;
        this.mLon = lon;
        this.mTsunami = tsunami;
        this.mDetail = detail;
    }

    private Earthquake(Parcel in) {
        magnitude = in.readDouble();
        location = in.readString();
        time = in.readLong();
        url = in.readString();
        mLat = in.readDouble();
        mLon = in.readDouble();
        mTsunami = in.readInt();
        mDetail = in.readString();
    }

    public static final Creator<Earthquake> CREATOR = new Creator<Earthquake>() {
        @Override
        public Earthquake createFromParcel(Parcel in) {
            return new Earthquake(in);
        }

        @Override
        public Earthquake[] newArray(int size) {
            return new Earthquake[size];
        }
    };

    public double getMagnitude() {
        return magnitude;
    }

    public String getLocation() {
        return location;
    }

    public long getTime() {
        return time;
    }

    public String getUrl() {
        return url;
    }

    public double getLat() {
        return mLat;
    }

    public double getLon() {
        return mLon;
    }

    public int getTsunami() {
        return mTsunami;
    }

    public String getDetail() {
        return mDetail;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeDouble(magnitude);
        parcel.writeString(location);
        parcel.writeLong(time);
        parcel.writeString(url);
        parcel.writeDouble(mLat);
        parcel.writeDouble(mLon);
        parcel.writeInt(mTsunami);
        parcel.writeString(mDetail);

    }
}
