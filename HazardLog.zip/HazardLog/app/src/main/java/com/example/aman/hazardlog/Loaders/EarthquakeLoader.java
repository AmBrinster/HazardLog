package com.example.aman.hazardlog.Loaders;

import android.app.Activity;
import android.content.AsyncTaskLoader;

import com.example.aman.hazardlog.Earthquakes.Earthquake;
import com.example.aman.hazardlog.Earthquakes.QueryUtilsEarthquake;

import java.util.List;


public class EarthquakeLoader extends AsyncTaskLoader<List<Earthquake>> {

    private String mUrl;

    public EarthquakeLoader(Activity context, String url) {
        super(context);
        mUrl = url;
    }

    @Override
    protected void onStartLoading() {
        forceLoad();
    }

    @Override
    public List<Earthquake> loadInBackground() {
        if (mUrl == null) {
            return null;
        }
        return QueryUtilsEarthquake.fetchEarthquakeData(mUrl);
    }

}
