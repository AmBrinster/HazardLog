package com.example.aman.hazardlog.Adapters;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import com.example.aman.hazardlog.CardFlipActivity;
import com.example.aman.hazardlog.Earthquakes.Earthquake;
import com.example.aman.hazardlog.Formattings.EarthquakeFormatter;
import com.example.aman.hazardlog.R;

import java.util.Date;
import java.util.List;

public class EarthquakeAdapter extends RecyclerView.Adapter<EarthquakeAdapter.ViewHolder> {

    private static final String LOCATION_SEPARATOR = " of ";
    private final LayoutInflater layoutInflater;
    private List<Earthquake> earthquakeList;
    private EarthquakeFormatter formatter;

    public EarthquakeAdapter(Activity context, List<Earthquake> datas) {
        super();
        layoutInflater = LayoutInflater.from(context);
        earthquakeList = datas;
    }

    public void clear() {
        earthquakeList.clear();
        notifyDataSetChanged();
    }

    public void addAll(List<Earthquake> earthquakes) {
        earthquakeList.clear();
        earthquakeList.addAll(earthquakes);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public EarthquakeAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.dark_list_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);

        formatter = new EarthquakeFormatter(layoutInflater.getContext());

        return viewHolder;
    }

    @SuppressLint({"SetJavaScriptEnabled", "ClickableViewAccessibility"})
    @Override
    public void onBindViewHolder(@NonNull EarthquakeAdapter.ViewHolder holder, int position) {

        final Earthquake currentEarthquake = earthquakeList.get(position);

        String formattedMagnitude = formatter.formatMagnitude(currentEarthquake.getMagnitude());
        holder.magnitudeView.setText("M "+formattedMagnitude);

        /*GradientDrawable magnitudeCircle = (GradientDrawable) holder.magnitudeView.getBackground();
        int magnitudeColor = formatter.getMagnitudeColor(currentEarthquake.getMagnitude());
        magnitudeCircle.setColor(magnitudeColor);*/

        int magColor = formatter.getMagnitudeColor(currentEarthquake.getMagnitude());
        holder.darkCard.setCardBackgroundColor(magColor);

        String originalLocation = currentEarthquake.getLocation();
        String primaryLocation;
        String locationOffset;
        if (originalLocation.contains(LOCATION_SEPARATOR)) {
            String[] parts = originalLocation.split(LOCATION_SEPARATOR);
            locationOffset = parts[0] + LOCATION_SEPARATOR;
            primaryLocation = parts[1];
        } else {
            locationOffset = layoutInflater.getContext().getString(R.string.near_the);
            primaryLocation = originalLocation;
        }
        holder.primaryLocationView.setText(primaryLocation);
        holder.locationOffsetView.setText(locationOffset);

        Date dateObject = new Date(currentEarthquake.getTime());
        String formattedDate = formatter.formatDate(dateObject);
        holder.dateView.setText(formattedDate);

        String formattedTime = formatter.formatTime(dateObject);
        holder.timeView.setText(formattedTime);

        holder.darkCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(layoutInflater.getContext(), CardFlipActivity.class);
                intent.putExtra("resourceValue", 1);
                intent.putExtra("currentEarthquake", currentEarthquake);
                layoutInflater.getContext().startActivity(intent);

            }
        });

        final String url = "https://www.google.com/maps/@?api=1&map_action=map&center="
                + currentEarthquake.getLat() + "," + currentEarthquake.getLon() + "&zoom=11";

        holder.webView.setWebViewClient(new WebViewClient());
        holder.webView.getSettings().setJavaScriptEnabled(true);
        holder.webView.setVerticalScrollBarEnabled(true);
        holder.webView.setHorizontalScrollBarEnabled(true);
        holder.webView.loadUrl(url);

        holder.viewMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(layoutInflater.getContext(), CardFlipActivity.class);
                intent.putExtra("resourceValue", 2);
                intent.putExtra("currentEarthquake", currentEarthquake);
                layoutInflater.getContext().startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return earthquakeList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        private TextView magnitudeView, primaryLocationView, locationOffsetView, dateView, timeView, viewMap;
        //private View parentView;
        private CardView card1, card2, darkCard;
        //private ImageView imageView;
        private WebView webView;

        ViewHolder(View itemView) {
            super(itemView);
            //parentView = itemView;
            //imageView = itemView.findViewById(R.id.image);
            webView = itemView.findViewById(R.id.web);
            viewMap = itemView.findViewById(R.id.viewMap);
            darkCard = itemView.findViewById(R.id.darkCard);
            /*card1 = itemView.findViewById(R.id.card1);
            card2 = itemView.findViewById(R.id.card2);*/
            magnitudeView = itemView.findViewById(R.id.magnitude);
            primaryLocationView = itemView.findViewById(R.id.primary_location);
            locationOffsetView = itemView.findViewById(R.id.location_offset);
            dateView = itemView.findViewById(R.id.date);
            timeView = itemView.findViewById(R.id.time);
        }
    }
}
/*http://apis.mapmyindia.com/advancedmaps/v1/l4kvx4lh5k1qm57e1jbawpnv217asqsp/still_image?center=28.595939499830784,77.22556114196777&zoom=18
        final String url = "https://api.mapbox.com/styles/v1/mapbox/cj62n87yx3mvi2rp93sfp2w9z/static/"
                +currentEarthquake.getLon()+","+currentEarthquake.getLat()
                +",12.0,0,0/300x300?access_token=pk.eyJ1IjoiYW1icmluc3RlciIsImEiOiJjanE3OWgzdWgyZzB1NDNqeThzY2M2cjZ3In0.4GsRQHAWzTDTZ-xMCBcgxw";
        final String url = "https://www.google.com/maps/search/?api=1&query="
        +currentEarthquake.getLat()+","+currentEarthquake.getLon();*/
/*Picasso.with(layoutInflater.getContext()).load(url).fit().centerCrop().into(holder.imageView);*/
/*holder.webView.setOnTouchListener(new View.OnTouchListener() {

            public final static int FINGER_RELEASED = 0;
            public final static int FINGER_TOUCHED = 1;
            public final static int FINGER_DRAGGING = 2;
            public final static int FINGER_UNDEFINED = 3;

            private int fingerState = FINGER_RELEASED;

            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {

                    case MotionEvent.ACTION_DOWN:
                        if (fingerState == FINGER_RELEASED) fingerState = FINGER_TOUCHED;
                        else fingerState = FINGER_UNDEFINED;
                        break;

                    case MotionEvent.ACTION_UP:
                        if(fingerState != FINGER_DRAGGING) {
                            fingerState = FINGER_RELEASED;
                            // Your onClick codes

                            Intent intent = new Intent(layoutInflater.getContext(), CardFlipActivity.class);
                            intent.putExtra("resourceValue", 2);
                            intent.putExtra("currentEarthquake", currentEarthquake);
                            layoutInflater.getContext().startActivity(intent);

                        }
                        else if (fingerState == FINGER_DRAGGING) fingerState = FINGER_RELEASED;
                        else fingerState = FINGER_UNDEFINED;
                        break;

                    case MotionEvent.ACTION_MOVE:
                        if (fingerState == FINGER_TOUCHED || fingerState == FINGER_DRAGGING) fingerState = FINGER_DRAGGING;
                        else fingerState = FINGER_UNDEFINED;
                        break;

                    default:
                        fingerState = FINGER_UNDEFINED;

                }

                return false;
            }
        });*/

        /*holder.webView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(layoutInflater.getContext(), CardFlipActivity.class);
                intent.putExtra("resourceValue", 2);
                intent.putExtra("currentEarthquake", currentEarthquake);
                layoutInflater.getContext().startActivity(intent);

            }
        });*/