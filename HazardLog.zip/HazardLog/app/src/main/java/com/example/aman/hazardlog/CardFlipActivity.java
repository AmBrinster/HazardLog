package com.example.aman.hazardlog;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import com.example.aman.hazardlog.Earthquakes.Earthquake;
import com.example.aman.hazardlog.Formattings.EarthquakeFormatter;

import java.util.Date;

public class CardFlipActivity extends AppCompatActivity {

    int resource;
    Earthquake currentEarthquake;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flip);

        Intent intent = getIntent();
        resource = intent.getIntExtra("resourceValue", 1);
        currentEarthquake = intent.getParcelableExtra("currentEarthquake");

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.containerFrame, new CardBackFragment())
                .commit();

    }

    public static class CardBackFragment extends Fragment {

        CardFlipActivity activity;
        EarthquakeFormatter earthquakeFormatter;
        TextView back,
                firstMag, secondMag, thirdMag, fourthMag, fifthMag, sixthMag, seventhMag, eighthMag,
                firstDesc, secondDesc, thirdDesc, fourthDesc, fifthDesc, sixthDesc, seventhDesc, eighthDesc;
        WebView webView;
        View firstView, secondView, thirdView, fourthView, fifthView, sixthView, seventhView, eighthView;
        CardView cardView;

        public CardBackFragment() {
        }

        @Override
        public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {

            View view;
            activity = (CardFlipActivity) getActivity();
            earthquakeFormatter = new EarthquakeFormatter(activity);
            cardView = activity.findViewById(R.id.containerFrame);

            int imgColor = earthquakeFormatter.getMagnitudeColor(activity.currentEarthquake.getMagnitude());
            cardView.setCardBackgroundColor(imgColor);

            if (activity.resource == 1) {
                view = inflater.inflate(R.layout.card1_back_flip, container, false);

                firstView = view.findViewById(R.id.firstInclude);
                secondView = view.findViewById(R.id.secondInclude);
                thirdView = view.findViewById(R.id.thirdInclude);
                fourthView = view.findViewById(R.id.fourthInclude);
                fifthView = view.findViewById(R.id.fifthInclude);
                sixthView = view.findViewById(R.id.sixthInclude);
                seventhView = view.findViewById(R.id.seventhInclude);
                eighthView = view.findViewById(R.id.eightInclude);

                firstMag = firstView.findViewById(R.id.magText);
                secondMag = secondView.findViewById(R.id.magText);
                thirdMag = thirdView.findViewById(R.id.magText);
                fourthMag = fourthView.findViewById(R.id.magText);
                fifthMag = fifthView.findViewById(R.id.magText);
                sixthMag = sixthView.findViewById(R.id.magText);
                seventhMag = seventhView.findViewById(R.id.magText);
                eighthMag = eighthView.findViewById(R.id.magText);

                firstDesc = firstView.findViewById(R.id.desText);
                secondDesc = secondView.findViewById(R.id.desText);
                thirdDesc = thirdView.findViewById(R.id.desText);
                fourthDesc = fourthView.findViewById(R.id.desText);
                fifthDesc = fifthView.findViewById(R.id.desText);
                sixthDesc = sixthView.findViewById(R.id.desText);
                seventhDesc = seventhView.findViewById(R.id.desText);
                eighthDesc = eighthView.findViewById(R.id.desText);

                loadView();
                loadUrl();

            } else {
                view = inflater.inflate(R.layout.card2_back_flip, container, false);
                webView = view.findViewById(R.id.backWeb);
                loadWeb();
            }
            back = view.findViewById(R.id.backCardFlip);
            onBackClick();

            return view;

        }

        private void loadUrl() {
            eighthDesc.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final String url = activity.currentEarthquake.getUrl();
                    Uri earthquakeUri = Uri.parse(url);

                    Intent intent = new Intent(Intent.ACTION_VIEW, earthquakeUri);
                    startActivity(intent);
                }
            });
        }

        private void loadView() {
            String lat, lon;
            lat = (activity.currentEarthquake.getLat() < 0)
                    ? (Math.abs(activity.currentEarthquake.getLat()) + "° S")
                    : (activity.currentEarthquake.getLat() + "° N");
            lon = (activity.currentEarthquake.getLon() < 0)
                    ? (Math.abs(activity.currentEarthquake.getLon()) + "° W")
                    : (activity.currentEarthquake.getLon() + "° E");

            String title = activity.currentEarthquake.getDetail();
            String magnitude = String.valueOf(activity.currentEarthquake.getMagnitude());
            String location = activity.currentEarthquake.getLocation();
            String epicenter = lat + ", " + lon + " (Latitude, Longitude)";
            Date dateObj = new Date(activity.currentEarthquake.getTime());
            String date = earthquakeFormatter.formatDate(dateObj);
            String time = earthquakeFormatter.formatTime(dateObj);
            String tsunami = String.valueOf(activity.currentEarthquake.getTsunami());
            String url = activity.currentEarthquake.getUrl();

            /*firstMag.setText("Title");
            firstDesc.setText(title);
            firstDesc.setTextColor(Color.parseColor("#ffffff"));*/

            firstMag.setText(title);
            firstMag.setTextColor(Color.parseColor("#4a0072"));

            secondMag.setText("Magnitude");
            secondDesc.setText(magnitude);
            secondDesc.setTextColor(Color.parseColor("#ffffff"));

            thirdMag.setText("Location");
            thirdDesc.setText(location);
            thirdDesc.setTextColor(Color.parseColor("#ffffff"));

            fourthMag.setText("Epicenter");
            fourthDesc.setText(epicenter);
            fourthDesc.setTextColor(Color.parseColor("#ffffff"));

            fifthMag.setText("Date");
            fifthDesc.setText(date);
            fifthDesc.setTextColor(Color.parseColor("#ffffff"));

            sixthMag.setText("Time");
            sixthDesc.setText(time);
            sixthDesc.setTextColor(Color.parseColor("#ffffff"));

            seventhMag.setText("Tsunami");
            seventhDesc.setText(tsunami);
            seventhDesc.setTextColor(Color.parseColor("#ffffff"));

            eighthMag.setText("Detail");
            eighthDesc.setText(url);
            eighthDesc.setTextColor(Color.parseColor("#4a0072"));
        }

        @SuppressLint("SetJavaScriptEnabled")
        private void loadWeb() {
            final String url = "https://www.google.com/maps/search/?api=1&query="
                    + activity.currentEarthquake.getLat() + "," + activity.currentEarthquake.getLon();

            webView.setWebViewClient(new WebViewClient());
            webView.getSettings().setJavaScriptEnabled(true);
            webView.setVerticalScrollBarEnabled(true);
            webView.setHorizontalScrollBarEnabled(true);
            webView.loadUrl(url);
        }

        public void onBackClick() {
            back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    /*Intent intent = new Intent(getActivity(), MainActivity.class);
                    Objects.requireNonNull(getActivity()).startActivity(intent);*/
                    activity.onBackPressed();
                }
            });
        }

    }


}
