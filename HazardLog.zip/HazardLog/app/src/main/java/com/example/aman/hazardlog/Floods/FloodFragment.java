package com.example.aman.hazardlog.Floods;

import android.support.v4.app.Fragment;

public class FloodFragment extends Fragment {

    public FloodFragment(){

    }



}
