package com.example.aman.hazardlog.Earthquakes;

import android.app.LoaderManager;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.example.aman.hazardlog.Adapters.EarthquakeAdapter;
import com.example.aman.hazardlog.Loaders.EarthquakeLoader;
import com.example.aman.hazardlog.PredictActivity;
import com.example.aman.hazardlog.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class EarthquakeFragment extends Fragment
        implements LoaderManager.LoaderCallbacks<List<Earthquake>>,
        SharedPreferences.OnSharedPreferenceChangeListener {

    private static final String USGS_REQUEST_URL =
            "https://earthquake.usgs.gov/fdsnws/event/1/query";
    private static final int EARTHQUAKE_LOADER_ID = 1;
    private EarthquakeAdapter mAdapter;
    private RecyclerView earthquakeListView;
    private static final String SAVED_LAYOUT = "key";
    private static final String SAVED_LAYOUT_STATE = "state";
    private static final String SAVED_LAYOUT_POSITION = "position";
    private Parcelable state;
    private Bundle mBundle;
    private int position;

    public EarthquakeFragment() {

    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        setHasOptionsMenu(true);
        View rootView = inflater.inflate(R.layout.view_activity, container, false);

        earthquakeListView = rootView.findViewById(R.id.recycle);

        mAdapter = new EarthquakeAdapter(getActivity(), new ArrayList<Earthquake>());

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());

        prefs.registerOnSharedPreferenceChangeListener(this);

        ConnectivityManager connMgr = (ConnectivityManager)
                Objects.requireNonNull(getActivity()).getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = Objects.requireNonNull(connMgr).getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            LoaderManager loaderManager = getActivity().getLoaderManager();
            loaderManager.initLoader(EARTHQUAKE_LOADER_ID, null, this);
        } else {
            View loadingIndicator = getActivity().findViewById(R.id.loading_indicator);
            loadingIndicator.setVisibility(View.GONE);
        }
        earthquakeListView.setLayoutManager(new LinearLayoutManager(getActivity()));
        earthquakeListView.setAdapter(mAdapter);


        return rootView;

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, final MenuInflater inflater) {
        inflater.inflate(R.menu.main, menu);
        final MenuItem item = menu.findItem(R.id.action_settings);
        item.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                int id = item.getItemId();
                if (id == R.id.action_settings) {
                    Intent intent = new Intent(getActivity(), EarthquakeSettingsActivity.class);
                    Objects.requireNonNull(getActivity()).startActivity(intent);
                    return true;
                }
                return false;
            }
        });

        final MenuItem predictItem = menu.findItem(R.id.predict);
        predictItem.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                int id = predictItem.getItemId();
                if (id == R.id.predict) {
                    Intent intent = new Intent(getActivity(), PredictActivity.class);
                    Objects.requireNonNull(getActivity()).startActivity(intent);
                    return true;
                }
                return false;
            }
        });

        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public Loader<List<Earthquake>> onCreateLoader(int i, Bundle bundle) {
        SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
        String minMagnitude = sharedPrefs.getString(
                getString(R.string.settings_min_magnitude_key),
                getString(R.string.settings_min_magnitude_default));

        String orderBy = sharedPrefs.getString(
                getString(R.string.settings_order_by_key),
                getString(R.string.settings_order_by_default)
        );

        String minLimit = sharedPrefs.getString(getString(R.string.settings_no_of_limit_key), getString(R.string.settings_no_of_limit_default));

        Uri baseUri = Uri.parse(USGS_REQUEST_URL);
        Uri.Builder uriBuilder = baseUri.buildUpon();

        uriBuilder.appendQueryParameter("format", "geojson");
        uriBuilder.appendQueryParameter("limit", minLimit);
        uriBuilder.appendQueryParameter("minmag", minMagnitude);
        uriBuilder.appendQueryParameter("orderby", orderBy);

        return new EarthquakeLoader(getActivity(), uriBuilder.toString());
    }

    @Override
    public void onLoadFinished(Loader<List<Earthquake>> loader, List<Earthquake> earthquakes) {
        View loadingIndicator = Objects.requireNonNull(getActivity()).findViewById(R.id.loading_indicator);
        loadingIndicator.setVisibility(View.GONE);
        mAdapter.clear();
        if (earthquakes != null && !earthquakes.isEmpty()) {
            mAdapter.addAll(earthquakes);
            if (state == null)
            earthquakeListView.setAdapter(mAdapter);
            else
             earthquakeListView.getLayoutManager().onRestoreInstanceState(state);
        }
    }

    @Override
    public void onLoaderReset(Loader<List<Earthquake>> loader) {
        mAdapter.clear();
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String s) {
        if (isAdded() && getActivity() != null) {
            if (s.equals(getString(R.string.settings_min_magnitude_key)) ||
                    s.equals(getString(R.string.settings_order_by_key)) || s.equals(getString(R.string.settings_no_of_limit_key))) {
                mAdapter.clear();
                View loadingIndicator = Objects.requireNonNull(getActivity()).findViewById(R.id.loading_indicator);
                loadingIndicator.setVisibility(View.VISIBLE);
                state = null;
                getActivity().getLoaderManager().restartLoader(EARTHQUAKE_LOADER_ID, null, this);
            }
        }
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        state = earthquakeListView.getLayoutManager().onSaveInstanceState();
        outState.putParcelable(SAVED_LAYOUT_STATE, state);
    }

    @Override
    public void onViewStateRestored(@Nullable Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);
        if (savedInstanceState!=null){
            state = savedInstanceState.getParcelable(SAVED_LAYOUT_STATE);
//            earthquakeListView.getLayoutManager().onRestoreInstanceState(state);
        }
    }


}

/*@Override
    public void onResume() {
        super.onResume();
        if (earthquakeListView!=null)
            earthquakeListView.getLayoutManager().onRestoreInstanceState(state);
    }*/

    /*@Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        state = earthquakeListView.getLayoutManager().onSaveInstanceState();
        outState.putParcelable(SAVED_LAYOUT, state);
        position = ((LinearLayoutManager)earthquakeListView.getLayoutManager()).findFirstVisibleItemPosition();
        outState.putInt(SAVED_LAYOUT_POSITION, position);
        super.onSaveInstanceState(outState);
    }



    @Override
    public void onViewStateRestored(@Nullable Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);
        if (state!=null) {
            assert savedInstanceState != null;
            state = savedInstanceState.getParcelable(SAVED_LAYOUT);
            position = savedInstanceState.getInt(SAVED_LAYOUT_POSITION);
        }
    }

    @Override
    public void onResume() {
        *//*if (mBundle != null) {
            Parcelable listState = mBundle.getParcelable(SAVED_LAYOUT);
            int position = mBundle.getInt(SAVED_LAYOUT_POSITION);
            earthquakeListView.getLayoutManager().onRestoreInstanceState(listState);
            earthquakeListView.getLayoutManager().scrollToPosition(position);
        }*//*
        if (state!=null){
            earthquakeListView.getLayoutManager().onRestoreInstanceState(state);
            earthquakeListView.getLayoutManager().scrollToPosition(position);
        }
        super.onResume();
    }*/

    /*@Override
    public void onPause() {
        super.onPause();
        mBundle = new Bundle();
        Parcelable listState = earthquakeListView.getLayoutManager().onSaveInstanceState();
        int position = ((LinearLayoutManager) earthquakeListView.getLayoutManager()).findFirstVisibleItemPosition();
        mBundle.putParcelable(SAVED_LAYOUT_STATE, listState);
        mBundle.putInt(SAVED_LAYOUT_POSITION, position);
    }*/
